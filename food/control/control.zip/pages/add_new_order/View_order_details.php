<div class="panel panel-default">
    <div class="panel-heading">Order Details</div>
    <div class="panel-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Order Id#</th>
                    <th>Table No</th>
                    <th>Order Type</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo $get_order[0]['id']; ?></td>
                    <td >
                        <?php
                        if ($get_order[0]['order_type'] != 2) { ?>


                            
                            <form class="form-inline" action="" method="post" >
                                
                                <div class="form-group error_class <?php if($get_order[0]['table_no'] == ""){echo "has-error has-feedback";}?>">
                                    <input class="form-control " style="width:200px;" type="text"  placeholder="Enter Table No" onkeyup="table_shift(this.value);" value="<?php echo $get_order[0]['table_no']; ?>">
                                    <?php if($get_order[0]['table_no'] == ""){?><span class="glyphicon glyphicon-remove form-control-feedback"></span><?php }?>
                                    
                                </div>
                                
                            </form>


                        <?php } else {
                            echo "NA";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($get_order[0]['order_type'] == 1) {
                            echo "OFFLINE";
                        } else {
                            echo "ONLINE";
                        }
                        ?>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>


<script>
    function table_shift(new_table_no) {
        $.ajax({
            type: "POST",
            url: "shift_table.php?order_id=" + "<?php echo $order_id; ?>",
            data: {
                table_no: new_table_no
            },
            success: function(result) {
                $(".error_class").removeClass("has-error");
                $(".error_class").removeClass("has-feedback");
                $(".form-control-feedback").hide();
            }
        });
    };
</script>